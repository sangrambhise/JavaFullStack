package com.wipro.app;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.wipro.model.Pan;
//import com.wipro.util.HibernateUtil;

public class App2 {
    public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction transaction = null;

        try {
            transaction = session.beginTransaction();

            Pan pan = new Pan("Ravi Kumar", "ABCDE1234F");
            session.persist(pan);

            transaction.commit();
            System.out.println("PAN record saved successfully!");

        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}

