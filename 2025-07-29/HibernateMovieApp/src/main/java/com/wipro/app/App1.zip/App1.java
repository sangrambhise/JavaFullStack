package com.wipro.app;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.wipro.model.Movie;
//import com.wipro.util.HibernateUtil;

public class App1 {
    public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction transaction = null;

        try {
            transaction = session.beginTransaction();

            Movie m = new Movie("Titanic", "English", 8.0);
            session.persist(m);

            transaction.commit();
            System.out.println("Movie saved successfully!");

        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}
